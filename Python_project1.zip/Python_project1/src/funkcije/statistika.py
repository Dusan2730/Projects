
from funkcije.klijent import sve_prijave, ucitani_treninzi
from funkcije.prijavakorisnika import postojece_korisnickoime

#Funkcija "statisticki_prikaz" prikazuje statistiku treninga za korisnika (klijenta ili trenera). 
# Ukoliko je korisnik tipa "klijent", funkcija prikazuje kategorije treninga i imena trenera na koje se klijent prijavio. 
# Ukoliko je korisnik tipa "trener", funkcija prikazuje kategorije treninga koje trener drži i broj prijava za svaki od tih treninga.
def statisticki_prikaz(korisnik):
    tip = korisnik["tip"]

    if tip == "klijent":
        prijave = sve_prijave()
        treninzi = ucitani_treninzi()
        sifre_treninga = []

        for prijava in prijave:
            if prijava["korisnickoime"] == korisnik["korisnickoime"]:
                sifre_treninga.append(prijava["sifra_treninga"])

        for sifra in sifre_treninga:
            i = 0
            for prijava in prijave:
                if prijava["sifra_treninga"] == sifra:
                    i += 1
            for trening in treninzi:
                if trening["sifra_treninga"] == sifra:
                    trener = postojece_korisnickoime(
                        trening["korisnicko_ime_trenera"])

                    print(
                        f"Kategorija: {trening['kategorija']} - Trener: {trener['ime']} {trener['prezime']}")

    elif tip == "trener":
        treninzi = ucitani_treninzi()
        prijave = sve_prijave()
        for trening in treninzi:
            if trening["korisnicko_ime_trenera"] == korisnik["korisnickoime"]:
                i = 0
                for prijava in prijave:
                    if prijava["sifra_treninga"] == trening["sifra_treninga"]:
                        i += 1
                print(
                    f"Kategorija: {trening['kategorija']} - Broj prijava: {i}")