import datetime
import json
from funkcije.klijent import sve_prijave, ucitaj_sve_treninge
from funkcije.prijavakorisnika import generisana_sifra, postojece_korisnickoime, ucitaj_sve_korisnike
#Funkcija "dodaj_trening" dodaje novi trening. Funkcija proverava tip korisnika i omogućava pristup samo trenerima. 
# Nakon toga se kreira jedinstvena šifra za trening, unosi dan i vreme početka i završetka treninga, te kategorija treninga. 
# Svi uneseni podaci se spremaju u json datoteku "treninzi".
def dodaj_trening(prijavljenikorisnik):
    if prijavljenikorisnik["tip"]!="trener":
        print("Nemate pravo pristupa")
        return
    sifra=generisana_sifra()

    svitreninzi=[]
    try:
        f= open("./data/treninzi.json", "r") 
        svitreninzi = json.load(f)
    except Exception:
        print("Greska")
    finally:
        f.close
    for trening in svitreninzi:
        while trening["sifra_treninga"]==sifra:
            sifra=generisana_sifra()
    
    sati=range(0,24)
    dani=["ponedeljak","utorak","sreda","cetvrtak","petak","subota","nedelja"]
    dan=input("Unesite dan u sedmici (ponedeljak - nedelja): ")
    while dan not in dani:
        print("Unesite odgovarajuci dan")
        dan=input("Unesite dan u sedmici (ponedeljak - nedelja): ")
    sat=input("Unesite vreme pocetka treninga: ")
    while int(sat) not in sati:
        print("Greska")
        sat=input("Unesite vreme pocetka treninga: ")
    satdo=input("Unesite vreme zavrsetka treninga: ")
    while int(satdo) not in sati:
        print("Greska")
        satdo=input("Unesite vreme zavrsetka treninga: ")

    kategorije=["pilates","tone","core","pump","TRX"]
    for kategorija in kategorije:
        print (kategorija)
    izbor_kategorije=input("Izaberite kategoriju treninga 1,2,3,4,5 :")
    izabrana_kategorija=""
    if izbor_kategorije=="1":
        izabrana_kategorija="pilates"
    elif izbor_kategorije=="2":
        izabrana_kategorija="tone"
    elif izbor_kategorije=="3":
        izabrana_kategorija="core"
    elif izbor_kategorije=="4":
        izabrana_kategorija="pump"
    elif izbor_kategorije=="5":
        izabrana_kategorija="TRX"
    else:
        while izabrana_kategorija=="":
            izbor_kategorije=input("Izaberite kategoriju treninga 1,2,3,4,5 :")
    trening={
        "sifra_treninga": sifra,
        "korisnicko_ime_trenera":prijavljenikorisnik["korisnickoime"],
        "raspored":f"{sat}h:{satdo}h,{dan}",
        "kategorija": izabrana_kategorija                  
    }
    
        
    svitreninzi.append(trening)
    try:
        f= open("./data/treninzi.json", "w")
        json.dump(svitreninzi,f)
            
    except Exception:
        print("Greska")
    finally:
        f.close()

#Ova funkcija formira string sa informacijama o treningu, koristeći redni broj, informacije o treningu i broj prijavljenih korisnika.
def formatiran_trening(redni_broj,trening):
    format=sve_prijave()
    trener=postojece_korisnickoime(trening["korisnicko_ime_trenera"])
    broj_prijava=0
    for prijava in format:
        if prijava["sifra_treninga"]==trening["sifra_treninga"]:
            broj_prijava += 1
        return f"Redni broj:{redni_broj},sifra treninga: {trening['sifra_treninga']},trener: {trener['ime']} {trener['prezime']},raspored: {trening['raspored']},kategorija {trening['kategorija']},broj prijavljenih: {broj_prijava}"

#Ova funkcija pretražuje treninge po danima ili po kategoriji. 
# Korisnik unosi 1 ili 2 za odabir opcije pretrage, a zatim odgovarajuće podatke (dan ili kategoriju). 
# Funkcija učitava sve treninge i sve korisnike, a zatim traži treninge koji odgovaraju unetim kriterijumima. 
# Pronađene treninge funkcija sortira po korisničkom imenu trenera, pronalazeći trenera iz liste svih korisnika. 
# Rezultat pretrage funkcija vraća kao listu pronadjenih treninga.
def trenerova_pretraga_treninga():

    print("1 Da li zelite pretragu po danima ")
    print("2 Da li zelite pretragu po kategoriji ")
    pretraga=input("Unesite 1 ili 2 ")
    while pretraga=="":
        pretraga=input("Unesite 1 ili 2 ")
    treninzi=ucitaj_sve_treninge()
    korisnici=ucitaj_sve_korisnike()
    if pretraga=="1":
        dani=["ponedeljak","utorak","sreda","cetvrtak","petak","subota","nedelja"]
        pretragadana=input("Unesite koji dan zelite ")
        while pretragadana not in dani:
            pretragadana=input("Unesite koji dan zelite ")
        pronadjenitreninzi=[]
        for trening in treninzi:
            termin=trening["raspored"].split(",")[1]
            if termin==pretragadana:
                pronadjenitreninzi.append(trening)
        
        
        for i in range (len(pronadjenitreninzi)):
            trener=None
            korisnickoimetrenera=pronadjenitreninzi[i]["korisnicko_ime_trenera"]
            for korisnik in korisnici:
                if korisnik["korisnickoime"]==korisnickoimetrenera:
                    trener=korisnik
            
        return pronadjenitreninzi
    elif pretraga=="2":
        kategorije=["pilates","tone","core","pump","TRX"]
        izabrane_kategorije=[] 
        for kategorija in range(len(kategorije)):
            print("{}  {}".format(kategorija+1,kategorije[kategorija]))
        unos_kategorije=input("Unesite ime kategorije: ")
        while unos_kategorije not in kategorije:
            print("Neispavan unos probajte ponovo")
            unos_kategorije=input("Unesite ime kategorije: ")
        izabrana_kategorija=unos_kategorije.strip().split(",")
        for izabrana_kategorija in izabrane_kategorije:
            while izabrana_kategorija.strip() not in kategorije:
                izabrana_kategorija=input("Unesite validnu kategoriju ({}):".format(kategorije))

        trening_po_kategoriji=[]
        for trening in  treninzi:
            if trening["kategorija"]in izabrana_kategorija:
                trening_po_kategoriji.append(trening)
            
        for i in range(len(trening_po_kategoriji)):
            trener=None
            korisnickoimetrenera=trening_po_kategoriji[i]["korisnicko_ime_trenera"]
            for korisnik in korisnici:
                if korisnik["korisnickoime"]==korisnickoimetrenera:
                    trener=korisnik

        
    
        return trening_po_kategoriji
    else:
        print("Nepostojeca opcija")
#Ova funkcija proverava dostupnost termina za trening uzimajući u obzir sve trenutne termine i novi termin koji se želi dodati (dan i vreme). 
# Funkcija vraća "False" ako je termin već zauzet, a "True" ako je termin slobodan.
def dostupan_termin(svi_termini, dan, vreme):
    for t in svi_termini:
        termin_dan = t.split(",")[0].strip()
        termin_vreme = t.split(",")[1].strip()
        if termin_dan == dan and termin_vreme == vreme:
            return False
    return True
#Ova funkcija proverava da li uneto vreme u ispravnom formatu (HH:MM). Ako jeste, funkcija vraća True, u suprotnom False.
def dozvoljeno_vreme(vreme):
    if vreme == "":
        return False

    format = "%H:%M"
    try:
        datetime.datetime.strptime(vreme, format)
        return True
    except ValueError:
        return False


#Funkcija "izmena_treninga" pretražuje trenera (korisnika) i prikazuje njegove dostupne treninge.
# Korisnik može odabrati jedan trening i izabrati opciju 1 za brisanje termina ili opciju 2 za izmenu termina. 
# Novi termin se zatim proverava za zauzeće i, ako je slobodan, ažurira u datoteci "treninzi.json". 
# Ukoliko dođe do greške prilikom čitanja/pisanja fajla, ispisaće se poruka "Fajl ne postoji".
def izmena_treninga(korisnik):
    svi_termini=[]
    jedan_termin=[]
    termin=[]
    rezultat=[]
    treninzi = trenerova_pretraga_treninga()
    dostupni_treninzi = []
    for trening in treninzi:
        if trening["korisnicko_ime_trenera"] == korisnik["korisnickoime"]:
            dostupni_treninzi.append(trening)
            svi_termini.append(trening["raspored"])

    for i in range(len(dostupni_treninzi)):
        print(formatiran_trening(i+1, dostupni_treninzi[i]))

    izbor = input("Izaberi trening: ")
    izabran_trening = dostupni_treninzi[int(izbor) - 1]
    jedan_termin.append (izabran_trening["raspored"])
    for i in range(len(jedan_termin)):
        termin.append(i+1)
        termin.append(izabran_trening["raspored"])
    rezultat.append(termin)
    print (rezultat)  

    print(f'2 Dodaj termin')
    izbor = input("Izaberi opciju 1,2: ")

    if int(izbor) <= len(rezultat):
        izabran_termin = [rezultat[int(izbor) - 1]] [0]
        print("1 Izbrisi termin")
        print("2 Izmeni termin")

        izbor = input("Izaberi opciju: ")
        if izbor == "1":
            svi_termini.remove(izabran_termin)
        elif izbor == "2":
            svi_termini = izabran_termin.split(",")
            dan = svi_termini[0]
            vreme = svi_termini[1]
            print(izabran_termin)
            vreme_od = input("Unesite vreme od: ")
            while dozvoljeno_vreme(vreme_od) == False:
                print("Neispravno vreme")
                vreme_od = input("Unesite vreme od: ")
            vreme_do = input("Unesite vreme do: ")
            while dozvoljeno_vreme(vreme_do) == False:
                print("Neispravno vreme")
                vreme_do = input("Unesite vreme do: ")

            vreme = f"{vreme_od}-{vreme_do}"
            dan = input("Unesite dan: ")
            if dostupan_termin(jedan_termin, dan, vreme) == False:
                print("Termin je zauzet")
            else:
                izabran_trening["raspored"] = f"{dan},{vreme}"

    try:
        f = open("./data/treninzi.json", "w", encoding="utf-8")
        json.dump(treninzi, f)
        print("Uspesno ste izmenili termin")
    except Exception as error:
        print("Fajl ne postoji")
    finally:
        f.close()