
import csv
import datetime
import string
import json

from funkcije.prijavakorisnika import generisana_sifra, postojece_korisnickoime, ucitaj_sve_korisnike


#Ova funkcija učitava sve treninge iz fajla "treninzi.json" u listu "treninzi". 
# Nakon čitanja fajla, funkcija zatvara fajl i vraća listu učitanih treninga.
def ucitaj_sve_treninge():
   
    treninzi=[]
   
    f=open("./data/treninzi.json", "r")
    treninzi=json.load(f)
    f.close()
    
       
    return treninzi

korisnici=ucitaj_sve_korisnike()
treninzi=ucitaj_sve_treninge()


#funkcija čita podatke o treninzima iz datoteke treninzi.json i učitava ih u listu.
#  Ako datoteka ne postoji, vraća se poruka o grešci. Nakon što se završi čitanje, datoteka se zatvara.
def ucitani_treninzi():
    try:
        trening = open("./data/treninzi.json", "r", encoding="utf-8")
        treninzi = json.load(trening)
        return treninzi
    except FileNotFoundError:
        return "Greska"
    finally:
        trening.close()


#Ovo je funkcija za čitanje prijava iz CSV datoteke. 
# Funkcija koristi "with open" konstrukciju da otvori CSV datoteku sa putanjom "./data/prijave.csv", učitava svaku liniju i parsira je pomoću metode "strip()" i "split()". 
# Nakon toga, svaki red se pretvara u rečnik sa ključevima "sifra_prijave", "sifra_treninga", "korisnickoime" i "komentar", i dodaje u listu "prijave". 
# Funkcija na kraju zatvara datoteku i vraća listu prijava.
def sve_prijave():
    prijave=[]
    with open("./data/prijave.csv","r",encoding="UTF-8")as fp:
        for line in fp.readlines():
            linija=line.strip("\n").split(",")
            
            prijava={
                "sifra_prijave":linija[0],
                "sifra_treninga":linija[1],
                "korisnickoime":linija[2],
                "komentar":linija[3]
           }
            prijave.append(prijava)
            
        fp.close()
    return prijave


#Funkcija "pretraga_treninga" omogućava pretragu treninga po danima ili kategorijama. 
# Korisnik unosi 1 za pretragu po danima ili 2 za pretragu po kategorijama, nakon čega funkcija učitava sve treninge i korisnike. 
# Ako je izabrana pretraga po danima, funkcija traži od korisnika da unese željeni dan, a zatim prikazuje sve treninge za taj dan. 
# Ukoliko je izabrana pretraga po kategorijama, funkcija prikazuje listu dostupnih kategorija i traži od korisnika da unese željenu kategoriju, nakon čega prikazuje sve treninge za tu kategoriju. 
# Funkcija vraća rezultate pretrage.
def pretraga_treninga():

    print("1 Da li zelite pretragu po danima ")
    print("2 Da li zelite pretragu po kategoriji ")
    pretraga=input("Unesite 1 ili 2 ")
    while pretraga=="":
        pretraga=input("Unesite 1 ili 2 ")
    treninzi=ucitaj_sve_treninge()
    korisnici=ucitaj_sve_korisnike()
    if pretraga=="1":
        dani=["ponedeljak","utorak","sreda","cetvrtak","petak","subota","nedelja"]
        pretragadana=input("Unesite koji dan zelite ")
        while pretragadana not in dani:
            pretragadana=input("Unesite koji dan zelite ")
        pronadjenitreninzi=[]
        for trening in treninzi:
            termin=trening["raspored"].split(",")[1]
            if termin==pretragadana:
                pronadjenitreninzi.append(trening)
        
        
        for i in range (len(pronadjenitreninzi)):
            trener=None
            korisnickoimetrenera=pronadjenitreninzi[i]["korisnicko_ime_trenera"]
            for korisnik in korisnici:
                if korisnik["korisnickoime"]==korisnickoimetrenera:
                    trener=korisnik
            print(f"{i+1},sifra_treninga {pronadjenitreninzi[i]['sifra_treninga']},trener {trener['ime']} {trener['prezime']},kategorija {pronadjenitreninzi[i]['kategorija']},raspored {pronadjenitreninzi[i]['raspored']}")
        return pronadjenitreninzi
    elif pretraga=="2":
        kategorije=["pilates","tone","core","pump","TRX"]
        izabrane_kategorije=[] 
        for kategorija in range(len(kategorije)):
            print("{}  {}".format(kategorija+1,kategorije[kategorija]))
        unos_kategorije=input("Unesite ime kategorije: ")
        while unos_kategorije not in kategorije:
            print("Neispavan unos probajte ponovo")
            unos_kategorije=input("Unesite ime kategorije: ")
        izabrana_kategorija=unos_kategorije.strip().split(",")
        for izabrana_kategorija in izabrane_kategorije:
            while izabrana_kategorija.strip() not in kategorije:
                izabrana_kategorija=input("Unesite validnu kategoriju ({}):".format(kategorije))

        trening_po_kategoriji=[]
        for trening in  treninzi:
            if trening["kategorija"]in izabrana_kategorija:
                trening_po_kategoriji.append(trening)
            
        for i in range(len(trening_po_kategoriji)):
            trener=None
            korisnickoimetrenera=trening_po_kategoriji[i]["korisnicko_ime_trenera"]
            for korisnik in korisnici:
                if korisnik["korisnickoime"]==korisnickoimetrenera:
                    trener=korisnik

        
        print(f"{i+1},sifra_treninga {trening_po_kategoriji[i]['sifra_treninga']},trener {trener['ime']} {trener['prezime']},kategorija {trening_po_kategoriji[i]['kategorija']},raspored {trening_po_kategoriji[i]['raspored']}")
        return trening_po_kategoriji
    else:
        print("Nepostojeca opcija")

#ova funkcija služi za prijavljivanje na trening. Korisnik unosi svoj izbor treninga na koji želi da se prijavi i unosi komentar o tom treningu.
#funkcija proverava da li je korisnik vec prijavljen na taj trening i ako nije, upisuje novu prijavu u datoteku prijave.csv.       
#ukoliko korisnik vec ima prijavljen trening, funkcija ispisuje poruku da je vec prijavljen na taj trening.
def prijava_treninga(korisnik):

    izbor_pretrage=pretraga_treninga()
    prijava_na_trening=[]                     
    korisnikov_izbor=input("Izaberite trening 1 2 3 4 5..: ")
    izabrani_trening = izbor_pretrage[int(korisnikov_izbor) - 1]
    
    for prijava in prijava_na_trening:
        linija=prijava
        prva=prijava["sifra_treninga"].strip()
        druga=prijava["korisnickoime"].strip()
        if prva == izabrani_trening["sifra_treninga"] and druga == korisnik["korisnickoime"]:
            print("Vec ste se prijavili na ovaj trening")
            return

    komentar = input("Unesite komentar: ")
    if komentar == "":
        komentar = "Nema komentara"
    f = open("./data/prijave.csv", "a", encoding="utf-8")
    f.write(
        f"{generisana_sifra()},{izabrani_trening['sifra_treninga']},{korisnik['korisnickoime']},{komentar}\n")
    print("Uspesno ste se prijavili na trening")

#funkciju brisanje_prijave koristimo za brisanje prijave za trening u csv fajlu.
#funkcija čita sve linije u fajlu i stavlja ih u listu "nove_prijave"
#koristeći korisničko ime iz argumenta "korisnik", funkcija filtrira linije u "nove_prijave" koje su prijave određenog korisnika i stavlja ih u listu "lista".
#ako "lista" nema prijavljenih treninga, funkcija ispisuje poruku "Nemate prijavljenih treninga" i vraća se. 
# Inače, funkcija ispisuje sve informacije o prijavama u "lista" i čeka unos rednog broja od korisnika. Korisnik unosi redni broj željene prijave za brisanje.
#Nakon toga, funkcija otvara fajl "./data/prijave.csv" u write modu, i ponovo prolazi kroz sve linije u "nove_prijave".
#  Ako linija odgovara izabranoj prijavi za brisanje, funkcija je preskače. Inače, funkcija upisuje liniju u fajl. 
# Kada se petlja završi, funkcija ispisuje poruku "Uspesno ste obrisali prijavu".
#Ukoliko dođe do bilo kakve iznimke, funkcija će ispisati poruku "Greska".
def brisanje_prijave(korisnik):
    nove_prijave = []
    lista=[]
    try:
        
        with open("./data/prijave.csv", "r", encoding="utf-8") as f:
            nove_prijave = f.readlines()
            for prijava in nove_prijave:
                linije=prijava.strip().split(",")[2]
                poredak=korisnik["korisnickoime"]
                if linije == poredak:
                    lista.append(prijava)
                        

            if len(lista) == 0:
                print("Nemate prijavljenih treninga")
                return

            for i in range(len(lista)):
                print("Redni broj: {}".format(i+1))
                print("Sifra prijave: {}".format(
                    lista[i].strip().split(",")[0]))
                print("Sifra treninga: {}".format(
                    lista[i].strip().split(",")[1]))
                print("Korisnicko ime: {}".format(
                    lista[i].strip().split(",")[2]))
                print("Komentar: {}".format(
                    lista[i].strip().split(",")[3]))
                
            izbor = input("Unesite redni broj prijave: ")
            izabrana_prijava = lista[int(izbor)-1]
            

            with open("./data/prijave.csv", "w", encoding="utf-8")as f:
                
                for prijava in nove_prijave:
                    if (izabrana_prijava in prijava)==True:
                        continue
                    else:
                        f.write(prijava)
            print("Uspesno ste obrisali prijavu")

    except Exception as error:
        print("Greska")
    


#Ova funkcija štampa plan treninga za zadatog korisnika. Funkcija učitava podatke o prijavama i treninzima, pronalazi one koji su važeći za korisnika i čuva ih u JSON fajlu sa imenom formatiranim kao lozinka i ime i prezime korisnika. 
# Ako fajl ne može biti kreiran, prikazuje se poruka "Fajl ne postoji".
def stampanje_plana_treninga(korisnik):
    prijave = sve_prijave()
    treninzi = ucitani_treninzi()
    validne_prijave = []
    sifre_treninga = []

    for prijava in prijave:
        if prijava["korisnickoime"] == korisnik["korisnickoime"]:
            sifre_treninga.append(prijava["sifra_treninga"])

    for trening in treninzi:
        if trening["sifra_treninga"] in sifre_treninga:
            trener = postojece_korisnickoime(
                trening["korisnicko_ime_trenera"])
            validne_prijave.append({
                "kategorija": trening["kategorija"],
                "raspored": trening["raspored"],
                "trener": f"{trener['ime']} {trener['prezime']}"
            })

    rezultat = {
        "ime": korisnik["ime"],
        "prezime": korisnik["prezime"],
        "prijave": validne_prijave
    }

    try:
        fajl = open(
            f"./data/{korisnik['lozinka']}-{korisnik['ime']} {korisnik['prezime']}.json", "w", encoding="utf-8")
        json.dump(rezultat, fajl)
        print("Uspesno ste kreirali plan treninga")
    except Exception as error:
        print("Fajl ne postoji")
    finally:
        fajl.close()

