import json
import random
import string

#Ova funkcija učitava sve korisnike iz fajla "treninzi.json" u listu "korisnici". Nakon čitanja fajla, funkcija zatvara fajl i vraća listu učitanih korisnika.
def ucitaj_sve_korisnike():
   

    korisnici=[]
    
    f=open("./data/korisnici.json", "r")
    korisnici=json.load(f)
    f.close()
    
        
    return korisnici
#Ova funkcija generiše slučajno odabranu šifru od 8 karaktera koja se sastoji od 4 slova i 4 broja.
def generisana_sifra():
        slova=''.join(random.choices(string.ascii_uppercase, k=4))
        brojevi=''.join(random.choices(string.digits, k=4))
        sifra=''.join(random.sample(slova+brojevi, 8))
        return sifra

#Funkcija "prijava" traži od korisnika da unese korisničko ime i lozinku, 
# i vraća rezultat funkcije "prijavakorisnika" sa unetim korisničkim imenom i lozinkom kao argumentima.
def prijava():
    korisnickoime=input("Unesite korisnicko ime ")
    lozinka=input("Unesite lozinku ")
    
    return prijavakorisnika(korisnickoime,lozinka)
    

#Ova funkcija proverava da li postoji korisnik sa zadatim korisničkim imenom i lozinkom u fajlu "./data/korisnici.json". 
# Ako postoji, vraća informacije o korisniku. Ukoliko ne postoji, ispisuje "Greska".
def prijavakorisnika(korisnicko_ime,lozinka):

    with open("./data/korisnici.json","r")as f:
        data=json.load(f)
        for korisnik in data:
            if korisnik["korisnickoime"]== korisnicko_ime and korisnik["lozinka"]==lozinka:
                return korisnik
                
        print("Greska")

#Ova funkcija kreira novog korisnika unosom podataka: korisničkog imena, lozinke, imena, prezimena i email-a. 
# Ukoliko neko polje nije uneto, funkcija će ispisati poruku da "Sve mora biti uneto!". 
# Ukoliko su sva polja uneta, funkcija poziva funkciju "dodaj_korisnika()" koja će dodati novog korisnika u sistem.
def registracija():
    korisnickoime=input("Unesite korisnicko ime: ")
    lozinka=input("Unesite lozinku: ")
    ime=input("Unesite ime: ")
    prezime=input("Unesite prezime: ")
    email=input("Unesite email: ")
    if korisnickoime =="":
        print("Sve mora biti uneto!")
    elif lozinka=="":
        print("Sve mora biti uneto!")
    elif ime=="":
        print("Sve mora biti uneto!")
    elif prezime=="":
        print("Sve mora biti uneto!")
    elif email=="":
        print("Sve mora biti uneto!")
    
    else:
        korisnik={
            "korisnickoime":korisnickoime,
            "lozinka":lozinka,
            "ime":ime,
            "prezime":prezime,
            "email":email,
            "tip":"klijent"
        }
        dodaj_korisnika(korisnik)
        
        
            
        
#Ova funkcija proverava da li uneti email vec postoji u korisnicima. Ukoliko postoji, funkcija vraca True, u suprotnom False.
def postojeci_email(email):
    with open("./data/korisnici.json", "r") as fp:
        data = json.load(fp)
        for korisnik in data:
            if korisnik["email"] == email:
                return True
        return False

#Ova funkcija proverava da li postoji korisničko ime u bazi podataka i vraća detalje korisnika ako postoji, u suprotnom vraća None.
def postojece_korisnickoime(korisnickoime):
    with open("./data/korisnici.json", "r") as file:
        data = json.load(file)
        for korisnik in data:
            if korisnik["korisnickoime"] == korisnickoime:
                return korisnik
        return None

#Funkcija "dodaj_korisnika" proverava postojanje korisnika po email-u i korisničkom imenu. 
# Ako korisnik već postoji, funkcija ispisuje poruku "Korisnik već postoji". 
# Ukoliko korisnik ne postoji, funkcija čita podatke iz datoteke "korisnici.json" i dodaje novog korisnika u nju. 
# Na kraju, funkcija čuva izmene u datoteci.
def dodaj_korisnika(korisnik):
    if postojeci_email(korisnik["email"]):
        print("Korisnik vec postoji!")
        return
    elif postojece_korisnickoime(korisnik["korisnickoime"]):
        print("Korisnik vec postoji!")
        return
    else:
        print("Uspesno ste se registrovali!")
        print("------------------------------")
    with open("./data/korisnici.json", "r") as fp:
        data = json.load(fp)
    data.append(korisnik)
    with open("./data/korisnici.json", "w") as fp:
        json.dump(data, fp)



           