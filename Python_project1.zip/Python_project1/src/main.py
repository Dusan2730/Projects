from funkcije.klijent import brisanje_prijave,pretraga_treninga, prijava_treninga, stampanje_plana_treninga
from funkcije.statistika import statisticki_prikaz
from funkcije.trener import dodaj_trening, formatiran_trening, izmena_treninga, trenerova_pretraga_treninga
from funkcije.prijavakorisnika import prijava, registracija 

prijavljenikorisnik=None




while True:
    if prijavljenikorisnik==None:
        print("1 Prijava: ")
        print("2 Registracija: ")
        print("3 Izlaz: ")
        izbor=input("-Izaberite opciju 1,2,3- ")
        print("-------------------------------")
        if izbor == "1":
            prijavljenikorisnik=prijava()
        elif izbor=="2":
            registracija()
        elif izbor=="3":
            break
        else:
            print("Nepostojeca opcija")
    else:
        print("Dobro dosli " +prijavljenikorisnik["ime"]+"!")      
        if  prijavljenikorisnik["tip"]=="trener":
            print("1 Dodavanje treninga: ")
            print("2 Pretraga treninga: ")
            print("3 Izmena treninga:  ")
            print("4 Statisticki prikaz: ")
            print("5 Izlaz: ")
            izbor_trenera=input("Izaberite opciju: ")

            if izbor_trenera=="1":

                dodaj_trening(prijavljenikorisnik)
            
            elif izbor_trenera=="2":
                treninzi=trenerova_pretraga_treninga()
                if len(treninzi)==0:
                    print("Nema treninga za prikaz")
                else:
                    for i in range(len(treninzi)):
                        print(formatiran_trening(i+1,treninzi[i]))
            
            elif izbor_trenera=="3":
                izmena_treninga(prijavljenikorisnik) 

            elif izbor_trenera=="4":
                statisticki_prikaz(prijavljenikorisnik)
            elif izbor_trenera=="5":
                break
            else:
                print("Nepostojeca opcija!")
        
        if prijavljenikorisnik["tip"]=="klijent":
            print("1 Pretraga treninga")
            print("2 Formiranje prijave")
            print("3 Brisanje prijave")
            print("4 Statisticki prikaz")
            print("5 Stampanje plana treninga")
            print("6 Izlaz ")
            izbor_klijenta=input("Unesite 1 2 3 4 5: ")
            
            if izbor_klijenta=="1":
                pretraga_treninga()
           
            elif izbor_klijenta=="2":
                prijava_treninga(prijavljenikorisnik) 
            
            elif izbor_klijenta=="3":
                brisanje_prijave(prijavljenikorisnik) 
            elif izbor_klijenta=="4":
                statisticki_prikaz(prijavljenikorisnik)

            elif izbor_klijenta=="5":
                stampanje_plana_treninga(prijavljenikorisnik)
            elif izbor_klijenta=="6":
                break
            else:
                print("Nepostojeca opcija!")






                            



                    
            
                    




                 
